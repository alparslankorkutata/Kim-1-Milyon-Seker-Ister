﻿using System.Drawing;

namespace Kim1MilyonSekerIster.Properties
{
    internal class Resources
    {
        internal static Image milyoner;
        internal static Image seyirci;
        internal static Image yarıyarıya;

        public static Image Phone { get; internal set; }
    }
}